public class attractions_controller {

}
