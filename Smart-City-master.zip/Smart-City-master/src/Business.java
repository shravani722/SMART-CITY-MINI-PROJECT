public class Business extends User {
    public Business(String name,String pass){
        super(name, pass);
    }
}